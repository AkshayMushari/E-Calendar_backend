package com.evernorth.ecalender.repository;

import java.sql.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.data.repository.CrudRepository;

import com.evernorth.ecalender.entity.Schedule;

public interface ScheduleRepository extends CrudRepository<Schedule,Integer>{

	List<Schedule> findAllByDate(Date date);
	Optional<Schedule> findScheduleByEmployeeidAndDate(Integer employeeid,Date date);
}
