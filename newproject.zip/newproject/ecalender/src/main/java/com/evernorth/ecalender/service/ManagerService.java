package com.evernorth.ecalender.service;

import java.sql.Date;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.evernorth.ecalender.entity.Employee;
import com.evernorth.ecalender.entity.HolidaysEvents;
import com.evernorth.ecalender.entity.Schedule;
import com.evernorth.ecalender.repository.EmployeeRepository;
import com.evernorth.ecalender.repository.HolidaysEventsRepository;
import com.evernorth.ecalender.repository.ScheduleRepository;

import jakarta.transaction.Transactional;

@Service
@Transactional
public class ManagerService {
	@Autowired
	EmployeeRepository employeeRepository;
	@Autowired
	ScheduleRepository scheduleRepository;
	@Autowired
	HolidaysEventsRepository holidaysEventsRepository;

	public List<Object> listAllEmployees() {

		List<Employee> list = (List<Employee>) employeeRepository.findAll();
		List<Object> l = new ArrayList<>();
		for (Employee emp : list) {
			Map<String, Object> map = new HashMap();
			map.put("id", emp.getId());
			map.put("name", emp.getName());
			map.put("email", emp.getEmail());
			l.add(map);

		}
		return l;

	}

	public Map<String, Object> findEmployee(Integer id) {
		Optional<Employee> emp1 = employeeRepository.findById(id);
		Map<String, Object> map = new HashMap();
		if (emp1.isPresent()) {
			Employee emp = emp1.get();
			map.put("id", emp.getId());
			map.put("name", emp.getName());
			map.put("email", emp.getEmail());
		} else {
			map.put("error", "employee not found");
		}
		return map;
	}

	public List<Schedule> findScheduleOn(Date date) {
		return (List<Schedule>) scheduleRepository.findAllByDate(date);
	}

	public Optional<Schedule> findScheduleOfOn(Integer employeeid, Date date) {
		return scheduleRepository.findScheduleByEmployeeidAndDate(employeeid, date);
	}

	public Map<String, Object> findByEventDate(Date date) {
		Optional<HolidaysEvents> event = holidaysEventsRepository.findByEventDate(date);
		Map<String, Object> response = new HashMap<>();

		if (event.isEmpty()) {
			response.put("message", "No Event Found");
			response.put("status", "error");
		} else {
			response.put("event", event.get());
			response.put("status", "success");
		}

		return response;
	}

	public Map<String, Object> createEvent(HolidaysEvents newEvent) {
		Map<String, Object> response = new HashMap<>();
		HolidaysEvents savedEvent = holidaysEventsRepository.save(newEvent);
		response.put("message", "Event created successfully");
		response.put("event", savedEvent);
		return response;
	}
	public Schedule insertSchedule(Schedule schedule) {
		return scheduleRepository.save(schedule);
	}
		
       

}
