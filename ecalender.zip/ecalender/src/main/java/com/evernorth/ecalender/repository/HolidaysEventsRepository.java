package com.evernorth.ecalender.repository;

import org.springframework.data.repository.CrudRepository;

import com.evernorth.ecalender.entity.HolidaysEvents;

public interface HolidaysEventsRepository extends CrudRepository<HolidaysEvents,Integer>{

}
