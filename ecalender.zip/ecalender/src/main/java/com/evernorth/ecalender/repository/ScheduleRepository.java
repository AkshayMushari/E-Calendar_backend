package com.evernorth.ecalender.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.repository.CrudRepository;

import com.evernorth.ecalender.entity.Schedule;

public interface ScheduleRepository extends CrudRepository<Schedule,Integer>{

	Optional findByEmployeeid(Integer employeeid);

}
