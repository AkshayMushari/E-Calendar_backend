package com.evernorth.ecalender.entity;

import java.sql.Time;
import java.util.Date;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class HolidaysEvents {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	Integer id;
	String organizer;
	String eventName;
	Date eventDate;
	Time eventTime;

}
