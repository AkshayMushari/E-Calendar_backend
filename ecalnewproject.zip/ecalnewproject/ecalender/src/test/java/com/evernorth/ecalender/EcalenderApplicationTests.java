package com.evernorth.ecalender;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EcalenderApplicationTests {

	@Test
	void contextLoads() {
	}

}
