package com.evernorth.ecalender;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EcalenderApplication {

	public static void main(String[] args) {
		SpringApplication.run(EcalenderApplication.class, args);
	}

}
